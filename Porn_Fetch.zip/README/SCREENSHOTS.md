# Linux (Gnome, Wayland)
<img src="../src/frontend/screenshots/linux_1.png" alt="Image of the main page"/>

---
<img src="../src/frontend/screenshots/linux_2.png" alt="Image of the account page"/>

---
<img src="../src/frontend/screenshots/linux_3.png" alt="Image of the tools page"/>

---
<img src="../src/frontend/screenshots/linux_4.png" alt="Image of the settings page"/>

---
<img src="../src/frontend/screenshots/linux_5.png" alt="Image of the progressbars"/>

---
# macOS (virtualized)
<img src="../src/frontend/screenshots/apple_1.png" alt="Image of the progressbars"/>
