# 1.5
- Added CI 
- Made Readme.md and Build process simpler to understand
