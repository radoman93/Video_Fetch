# 1.9
- Fixed OS Error issue
- Added function to strip out special symbols in title, to prevent path issues
