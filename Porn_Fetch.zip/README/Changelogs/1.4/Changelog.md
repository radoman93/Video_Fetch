# 1.4
- Changed UI (stackedWidget)
