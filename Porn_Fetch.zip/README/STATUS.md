# 3.7
- [] Fix Translations once and forever
- [] YouPorn support
- [] Support XHamster Shorts
- [] Support Xhamster Searching
- [] Support Xhamster Playlists
- [] Update networking stuff a little bit
- [] Improve UI icons and general look (more consistent)
- [] Improve logging to server

